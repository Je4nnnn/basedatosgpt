<template>
  <div class="cancelar-cita">
    <h1>Cancelar Cita</h1>
    <div v-if="loading">Cargando citas…</div>
    <div v-else-if="error" class="error">{{ error }}</div>

    <ul v-else>
      <li v-for="c in citas" :key="c.id">
        <strong>ID:</strong> {{ c.id }}
        – {{ formatDateTime(c.fechaHora) }}
        con {{ c.medico.nombre }}
        <button @click="cancelar(c)">Cancelar</button>

      </li>
    </ul>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import axios from 'axios'
import { useRouter } from 'vue-router'

const citas = ref([])
const loading = ref(true)
const error = ref(null)
const router = useRouter()

function formatDateTime(dt) {
  return new Date(dt).toLocaleString()
}

async function fetchCitas() {
  loading.value = true
  error.value = null
  try {
    const email = localStorage.getItem('usuarioEmail')
    const resp = await axios.get(
      `http://localhost:8081/api/paciente/citas?email=${encodeURIComponent(email)}`
    )
    citas.value = resp.data
  } catch (e) {
    error.value = e.response?.data?.error || e.message
  } finally {
    loading.value = false
  }
}

async function cancelar(cita) {
  try {
    const email = localStorage.getItem('usuarioEmail')
    await axios.delete(
      `http://localhost:8081/api/paciente/citas/${cita.id}?email=${encodeURIComponent(email)}`
    )
    alert('Cita cancelada correctamente')

    // Redirige a la disponibilidad de ese médico
    router.push({
      name: 'VerDisponibilidad',
      params: { id: cita.medico.id },
      query: { fechaHoraInicio: cita.fechaHora }
    })
  } catch (e) {
    alert('Error al cancelar: ' + (e.response?.data?.error || e.message))
  }
}

function reprogramar(cita) {
  // Igual que cancelar, pero redirige directamente a agendar
  router.push({
    name: 'AgendarCita',
    params: { id: cita.medico.id },
    query: { fechaHoraInicio: cita.fechaHora }
  })
}

onMounted(fetchCitas)
</script>

<style scoped>
.error { color: red; }
.cancelar-cita { max-width: 600px; margin: 2rem auto; }
ul { list-style: none; padding: 0; }
li { margin-bottom: 1rem; }
button { margin-left: 0.5rem; }
</style>
