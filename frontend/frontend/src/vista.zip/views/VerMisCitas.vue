<template>
  <div class="mis-citas">
    <h1>Mis Citas Agendadas</h1>

    <div v-if="loading">Cargando citas…</div>
    <div v-else-if="error" class="error">{{ error }}</div>

    <table v-else>
      <thead>
        <tr>
          <th>ID</th>
          <th>Médico</th>
          <th>Fecha & Hora</th>
          <th>Motivo</th>
          <th>Estado</th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="c in citas" :key="c.id">
          <td>{{ c.id }}</td>
          <td>{{ c.medico.nombre }} ({{ c.medico.email }})</td>
          <td>{{ formatDateTime(c.fechaHora) }}</td>
          <td>{{ c.motivo }}</td>
          <td>{{ c.estado }}</td>
        </tr>
      </tbody>
    </table>

    <div v-if="citas.length === 0 && !loading">
      No tienes citas agendadas.
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import axios from 'axios'

const citas = ref([])
const loading = ref(true)
const error = ref(null)

function formatDateTime(dt) {
  // Opcional: formatea ISO a algo legible
  return new Date(dt).toLocaleString()
}

async function fetchCitas() {
  loading.value = true
  error.value = null

  try {
    const email = localStorage.getItem('usuarioEmail')
    if (!email) throw new Error('No estás autenticado')
    const resp = await axios.get(
      `http://localhost:8081/api/paciente/citas?email=${encodeURIComponent(email)}`
    )
    citas.value = resp.data
  } catch (e) {
    console.error(e)
    error.value = e.response?.data?.error || e.message
  } finally {
    loading.value = false
  }
}

onMounted(fetchCitas)
</script>

<style scoped>
.mis-citas {
  max-width: 800px;
  margin: 2rem auto;
}
table {
  width: 100%;
  border-collapse: collapse;
  margin-top: 1rem;
}
th, td {
  border: 1px solid #ccc;
  padding: 0.5rem;
  text-align: left;
}
.error {
  color: red;
  margin-top: 1rem;
}
</style>
