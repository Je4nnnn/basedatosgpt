<template>
  <div class="reprogramar-cita">
    <h1>Reprogramar Cita</h1>

    <div v-if="loading">Cargando citas…</div>
    <div v-else-if="error" class="error">{{ error }}</div>

    <ul v-else>
      <li v-for="c in citas" :key="c.id" style="margin-bottom: 1rem;">
        <strong>ID:</strong> {{ c.id }}
        – {{ formatDateTime(c.fechaHora) }}
        con {{ c.medico.nombre }}
        <button @click="reprogramar(c)" style="margin-left: 1rem;">
          Reprogramar
        </button>
      </li>
    </ul>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import axios from 'axios'
import { useRouter } from 'vue-router'

const citas   = ref([])
const loading = ref(true)
const error   = ref(null)
const router  = useRouter()

function formatDateTime(dt) {
  return new Date(dt).toLocaleString()
}

async function fetchCitas() {
  loading.value = true
  error.value   = null
  try {
    const email = localStorage.getItem('usuarioEmail')
    const resp  = await axios.get(
      `http://localhost:8081/api/paciente/citas?email=${encodeURIComponent(email)}`
    )
    citas.value = resp.data
  } catch (e) {
    error.value = e.response?.data?.error || e.message
  } finally {
    loading.value = false
  }
}

async function reprogramar(cita) {
  try {
    const email = localStorage.getItem('usuarioEmail')

    // 1) Cancelamos la cita actual
    await axios.delete(
      `http://localhost:8081/api/paciente/citas/${cita.id}`,
      { params: { email } }
    )

    // 2) Redirigimos a la lista de disponibilidad para este médico
    router.push({
      name: 'VerDisponibilidad',
      params: { id: cita.medico.id },
      query: {
        reprogramar: 'true',
        citaId:      cita.id,
        motivo:      cita.motivo
      }
    })
  } catch (e) {
    console.error(e)
    alert('Error al reprogramar: ' + (e.response?.data?.error || e.message))
  }
}

onMounted(fetchCitas)
</script>

<style scoped>
.error { color: red; }
.reprogramar-cita {
  max-width: 600px;
  margin: 2rem auto;
}
ul { list-style: none; padding: 0; }
li { display: flex; align-items: center; }
button { margin-left: 0.5rem; }
</style>

