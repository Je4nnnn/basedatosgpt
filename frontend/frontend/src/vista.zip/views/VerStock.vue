<template>
  <div>
    <h1>Stock de Medicamentos</h1>
    <ul>
      <li v-for="s in stock" :key="s.id">
        ID {{ s.medicamento.id }} – {{ s.medicamento.nombre }}: {{ s.cantidad }}
      </li>
    </ul>
  </div>
</template>
<script setup>
import { ref, onMounted } from 'vue'
import axios from 'axios'
const stock = ref([])
onMounted(async () => {
  const resp = await axios.get('http://localhost:8081/api/stock')
  stock.value = resp.data
})
</script>
