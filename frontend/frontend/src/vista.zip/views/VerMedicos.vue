<template>
  <div style="padding: 2rem;">
    <h1 style="text-align: center; margin-bottom: 2rem;">Médicos Disponibles</h1>
    <div
      v-for="medico in medicos"
      :key="medico.id"
      class="medico-card"
    >
      <h2>{{ medico.nombre }}</h2>
      <p>{{ medico.email }}</p>
      <button @click="verDisponibilidad(medico.id)">Ver disponibilidad</button>
    </div>
  </div>
</template>

<script>
export default {
  name: "VerMedicos",
  data() {
    return {
      medicos: [],
    };
  },
  mounted() {
    fetch("http://localhost:8081/api/usuarios")
      .then(res => res.json())
      .then(data => {
        const filtrados = data.filter(
          (usuario, index, self) =>
            usuario.rol === "MEDICO" &&
            index === self.findIndex(u => u.email === usuario.email)
        );
        this.medicos = filtrados;
      })
      .catch(err => console.error("Error cargando médicos:", err));
  },
  methods: {
    verDisponibilidad(medicoId) {
      this.$router.push(`/paciente/disponibilidad/${medicoId}`);
    },
  },
};
</script>

<style scoped>
.medico-card {
  background-color: #f5f5f5;
  padding: 1.5rem;
  margin-bottom: 1.5rem;
  border-radius: 8px;
  text-align: center;
}
</style>
