<template>
  <div class="paciente-home">
    <h1>Bienvenido, Paciente</h1>
    <div class="buttons">
      <button @click="router.push({ name: 'VerMedicos' })">
        Agendar Cita
      </button>
      <button @click="router.push({ name: 'VerMisCitas' })">
        Ver Mis Citas
      </button>
      <button @click="router.push({ name: 'CancelarCita' })">
        Cancelar Cita
      </button>
      <button @click="router.push({ name: 'HistorialMedico' })">
        Consultar Historial Médico
      </button>
      <button @click="router.push({ name: 'ReprogramarCita' })">
        Reprogramar Cita
      </button>
    </div>
  </div>
</template>

<script setup>
import { useRouter } from 'vue-router'
const router = useRouter()
</script>

<style scoped>
.paciente-home {
  max-width: 400px;
  margin: 2rem auto;
  text-align: center;
}
.buttons {
  display: flex;
  flex-direction: column;
  gap: 1rem;
  margin-top: 2rem;
}
button {
  padding: 0.75rem 1rem;
  font-size: 1rem;
  cursor: pointer;
  border: 1px solid #ccc;
  border-radius: 4px;
  background: #f9f9f9;
}
button:hover {
  background: #e9e9e9;
}
</style>
