<template>
  <div class="seleccionar-especialidad">
    <h1>Seleccionar Especialidad</h1>
    <p>Elige la especialidad médica para tu consulta:</p>

    <div class="especialidades-grid">
      <div
        v-for="especialidad in especialidades"
        :key="especialidad.value"
        class="especialidad-card"
        @click="seleccionarEspecialidad(especialidad.value)"
      >
        <div class="especialidad-icon">
          <i :class="especialidad.icon"></i>
        </div>
        <h3>{{ especialidad.label }}</h3>
        <p>{{ especialidad.descripcion }}</p>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue'
import { useRouter } from 'vue-router'

const router = useRouter()

const especialidades = ref([
  {
    value: 'CARDIOLOGIA',
    label: 'Cardiología',
    descripcion: 'Especialista del corazón y sistema cardiovascular',
    icon: '❤️'
  },
  {
    value: 'DERMATOLOGIA',
    label: 'Dermatología',
    descripcion: 'Especialista en piel, cabello y uñas',
    icon: '🧴'
  },
  {
    value: 'NEUROLOGIA',
    label: 'Neurología',
    descripcion: 'Especialista del sistema nervioso',
    icon: '🧠'
  },
  {
    value: 'PEDIATRIA',
    label: 'Pediatría',
    descripcion: 'Especialista en salud infantil',
    icon: '👶'
  },
  {
    value: 'MEDICINA_GENERAL',
    label: 'Medicina General',
    descripcion: 'Atención médica general y preventiva',
    icon: '👨‍⚕️'
  },
  {
    value: 'GINECOLOGIA',
    label: 'Ginecología',
    descripcion: 'Especialista en salud femenina',
    icon: '👩‍⚕️'
  },
  {
    value: 'TRAUMATOLOGIA',
    label: 'Traumatología',
    descripcion: 'Especialista en huesos y articulaciones',
    icon: '🦴'
  }
])

const seleccionarEspecialidad = (especialidad) => {
  router.push({
    path: '/paciente/medicos-especialidad',
    query: { especialidad }
  })
}
</script>

<style scoped>
.seleccionar-especialidad {
  max-width: 1200px;
  margin: 2rem auto;
  padding: 0 1rem;
}

.seleccionar-especialidad h1 {
  text-align: center;
  color: #2c3e50;
  margin-bottom: 1rem;
}

.seleccionar-especialidad p {
  text-align: center;
  color: #7f8c8d;
  margin-bottom: 2rem;
  font-size: 1.1rem;
}

.especialidades-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
  gap: 1.5rem;
}

.especialidad-card {
  background: white;
  border: 2px solid #ecf0f1;
  border-radius: 12px;
  padding: 2rem;
  text-align: center;
  cursor: pointer;
  transition: all 0.3s ease;
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
}

.especialidad-card:hover {
  border-color: #3498db;
  transform: translateY(-5px);
  box-shadow: 0 5px 20px rgba(52, 152, 219, 0.2);
}

.especialidad-icon {
  font-size: 3rem;
  margin-bottom: 1rem;
}

.especialidad-card h3 {
  color: #2c3e50;
  margin-bottom: 0.5rem;
  font-size: 1.3rem;
}

.especialidad-card p {
  color: #7f8c8d;
  font-size: 0.9rem;
  line-height: 1.4;
  margin: 0;
}

@media (max-width: 768px) {
  .especialidades-grid {
    grid-template-columns: 1fr;
  }

  .especialidad-card {
    padding: 1.5rem;
  }
}
</style>