<template>
  <div class="container">
    <div class="header">
      <button @click="volver" class="btn-volver">← Volver al inicio</button>
      <h2>Seleccionar Especialidad</h2>
      <p class="subtitle">Elige la especialidad médica que necesitas</p>
    </div>

    <div v-if="loading" class="loading">
      Cargando especialidades...
    </div>

    <div v-else class="especialidades-grid">
      <div
        v-for="especialidad in especialidades"
        :key="especialidad.codigo"
        class="especialidad-card"
        @click="seleccionarEspecialidad(especialidad)"
      >
        <div class="especialidad-icon">
          <i :class="getIconoEspecialidad(especialidad.codigo)"></i>
        </div>
        <h3>{{ especialidad.nombre }}</h3>
        <p>{{ especialidad.descripcion }}</p>
        <div class="especialidad-arrow">→</div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { useRouter } from 'vue-router'

const router = useRouter()
const loading = ref(true)

const especialidades = ref([
  {
    codigo: 'CARDIOLOGIA',
    nombre: 'Cardiología',
    descripcion: 'Especialista en enfermedades del corazón y sistema cardiovascular'
  },
  {
    codigo: 'DERMATOLOGIA',
    nombre: 'Dermatología',
    descripcion: 'Especialista en enfermedades de la piel, cabello y uñas'
  },
  {
    codigo: 'NEUROLOGIA',
    nombre: 'Neurología',
    descripcion: 'Especialista en enfermedades del sistema nervioso'
  },
  {
    codigo: 'PEDIATRIA',
    nombre: 'Pediatría',
    descripcion: 'Especialista en atención médica de niños y adolescentes'
  },
  {
    codigo: 'MEDICINA_GENERAL',
    nombre: 'Medicina General',
    descripcion: 'Atención médica integral y consultas generales'
  },
  {
    codigo: 'GINECOLOGIA',
    nombre: 'Ginecología',
    descripcion: 'Especialista en salud reproductiva femenina'
  },
  {
    codigo: 'TRAUMATOLOGIA',
    nombre: 'Traumatología',
    descripcion: 'Especialista en lesiones del sistema músculo-esquelético'
  }
])

onMounted(() => {
  // Simular carga (puedes reemplazar con llamada a API)
  setTimeout(() => {
    loading.value = false
  }, 500)
})

const getIconoEspecialidad = (codigo) => {
  const iconos = {
    'CARDIOLOGIA': 'fas fa-heartbeat',
    'DERMATOLOGIA': 'fas fa-user-md',
    'NEUROLOGIA': 'fas fa-brain',
    'PEDIATRIA': 'fas fa-baby',
    'MEDICINA_GENERAL': 'fas fa-stethoscope',
    'GINECOLOGIA': 'fas fa-female',
    'TRAUMATOLOGIA': 'fas fa-bone'
  }
  return iconos[codigo] || 'fas fa-user-md'
}

const seleccionarEspecialidad = (especialidad) => {
  router.push({
    path: '/paciente/medicos-especialidad',
    query: { especialidad: especialidad.codigo }
  })
}

const volver = () => {
  router.push('/paciente')
}
</script>

<style scoped>
.container {
  max-width: 1000px;
  margin: 2rem auto;
  padding: 0 1rem;
}

.header {
  margin-bottom: 2rem;
  text-align: center;
}

.btn-volver {
  background: #95a5a6;
  color: white;
  border: none;
  padding: 0.5rem 1rem;
  border-radius: 6px;
  cursor: pointer;
  margin-bottom: 1rem;
  font-size: 0.9rem;
  transition: background-color 0.3s ease;
}

.btn-volver:hover {
  background: #7f8c8d;
}

.container h2 {
  color: #2c3e50;
  margin: 0;
  font-size: 2rem;
}

.subtitle {
  color: #7f8c8d;
  margin: 0.5rem 0 0 0;
  font-size: 1.1rem;
}

.loading {
  text-align: center;
  padding: 3rem;
  font-size: 1.1rem;
  color: #7f8c8d;
}

.especialidades-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
  gap: 1.5rem;
}

.especialidad-card {
  background: white;
  border: 2px solid #e9ecef;
  border-radius: 12px;
  padding: 2rem;
  text-align: center;
  cursor: pointer;
  transition: all 0.3s ease;
  position: relative;
  overflow: hidden;
}

.especialidad-card:hover {
  transform: translateY(-4px);
  box-shadow: 0 8px 25px rgba(0, 0, 0, 0.15);
  border-color: #3498db;
}

.especialidad-icon {
  font-size: 3rem;
  color: #3498db;
  margin-bottom: 1rem;
}

.especialidad-card h3 {
  color: #2c3e50;
  margin: 0 0 1rem 0;
  font-size: 1.4rem;
  font-weight: 600;
}

.especialidad-card p {
  color: #7f8c8d;
  margin: 0;
  line-height: 1.5;
  font-size: 0.95rem;
}

.especialidad-arrow {
  position: absolute;
  bottom: 1rem;
  right: 1.5rem;
  font-size: 1.5rem;
  color: #3498db;
  opacity: 0;
  transition: opacity 0.3s ease;
}

.especialidad-card:hover .especialidad-arrow {
  opacity: 1;
}

/* Responsive design */
@media (max-width: 768px) {
  .container {
    margin: 1rem auto;
    padding: 0 0.5rem;
  }

  .especialidades-grid {
    grid-template-columns: 1fr;
    gap: 1rem;
  }

  .especialidad-card {
    padding: 1.5rem;
  }

  .container h2 {
    font-size: 1.6rem;
  }
}
</style>